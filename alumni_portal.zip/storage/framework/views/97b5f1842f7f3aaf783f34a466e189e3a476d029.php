<div class="profile-header">
    <div class="cover">
        <div class="gray-shade"></div>
        <figure>
            <img src="<?php echo e(asset('image/' . $user->timeline_picture)); ?>" class="img-fluid" alt="profile cover">
        </figure>
        <div class="cover-body d-flex justify-content-between align-items-center">
            <div>
                <a href="" data-toggle="modal" style="text-decoration: none;" data-target="#profile_picture">
                    <img class="profile-pic" src="<?php echo e(asset('image/' . $user->profile_picture)); ?>" alt="profile">
                </a>
                <span class="profile-name"><?php echo e(Str::ucfirst($user->name)); ?> <?php echo e(Str::ucfirst($user->middle_name)); ?>

                    <?php echo e(Str::ucfirst($user->last_name)); ?></span>
            </div>
        </div>
    </div>

    <div class="header-links">
        

        <ul class="links nav justify-content-center">
            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(url('admin_view_user_timeline', ['id' => $user->id])); ?>">Timeline</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(url('admin_view_user_photos', ['id' => $user->id])); ?>">Photos</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(url('home')); ?>">Home</a>
            </li>
        </ul>
    </div>
</div>
<?php /**PATH C:\Users\Administrator\Documents\GitHub\alumni_portal\resources\views/layouts/admin_view_user_timeline_menu.blade.php ENDPATH**/ ?>