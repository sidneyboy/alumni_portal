<div class="social-footer" id="reloader">
    <?php $__currentLoopData = $announcement_replies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $announcement_reply_details): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="social-comment">
            <a href class="pull-left">
                <img alt="image" src="<?php echo e(asset('image/' . $announcement_reply_details->user_admin->profile_picture)); ?>">
            </a>
            <div class="media-body">
                <?php if($announcement_reply_details->user_id == auth()->user()->id): ?>
                    <?php echo e(Str::ucfirst($announcement_reply_details->user_admin->name)); ?>

                    <?php echo e(Str::ucfirst($announcement_reply_details->user_admin->middle_name)); ?>

                    <?php echo e(Str::ucfirst($announcement_reply_details->user_admin->last_name)); ?>

                    <small class="text-muted"><?php echo e(date('F j, Y', strtotime($announcement_reply_details->created_at))); ?></small>
                <?php else: ?>
                    <a style="text-decoration: none" href="<?php echo e(url('admin_view_user_timeline', ['id' => $announcement_reply_details->user_id])); ?>">
                        <?php echo e(Str::ucfirst($announcement_reply_details->user_admin->name)); ?>

                        <?php echo e(Str::ucfirst($announcement_reply_details->user_admin->middle_name)); ?>

                        <?php echo e(Str::ucfirst($announcement_reply_details->user_admin->last_name)); ?>

                    </a>
                    <small class="text-muted"><?php echo e(date('F j, Y', strtotime($announcement_reply_details->created_at))); ?></small>
                <?php endif; ?>
                <br>
                <?php echo e($announcement_reply_details->content); ?>

                
                
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php /**PATH C:\Users\Administrator\Documents\GitHub\alumni_portal\resources\views/user_announcement_get_comments.blade.php ENDPATH**/ ?>