<form action="<?php echo e(route('admin_survey_proceed_process')); ?>" method="post">
    <?php echo csrf_field(); ?>
    <div class="row">
        <?php for($i = 0; $i < $no_of_questions; $i++): ?>
            <div class="col-md-12">
                <label for="">Question <?php echo e($i + 1); ?></label>
                <input type="text" class="form-control" name="questions[]" required>
            </div>
        <?php endfor; ?>
        <div class="col-md-12">
            <br />
            <input type="hidden" name="no_of_questions" value="<?php echo e($no_of_questions); ?>">
            <input type="hidden" name="survey_title" value="<?php echo e($survey_title); ?>">
            <button class="btn float-right btn-primary" type="submit">Submit</button>
        </div>
    </div>
</form>
<?php /**PATH C:\Users\Administrator\Documents\GitHub\alumni_portal\resources\views/admin_survey_proceed.blade.php ENDPATH**/ ?>