<div class="social-footer" id="reloader">
    <?php $__currentLoopData = $announcement_replies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $announcement_reply_details): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="social-comment">
            <a href class="pull-left">
                <img alt="image"
                    src="<?php echo e(asset('image/' . $announcement_reply_details->user_admin->profile_picture)); ?>">
            </a>
            <div class="media-body">
                <a href="#">
                    <?php echo e($announcement_reply_details->user_admin->name); ?>

                </a>
                <?php echo e($announcement_reply_details->content); ?>

                <br>

                <small
                    class="text-muted"><?php echo e(date('F j, Y', strtotime($announcement_reply_details->created_at))); ?></small>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php /**PATH C:\Users\Administrator\Documents\GitHub\alumni_portal\resources\views/admin_announcement_get_comments.blade.php ENDPATH**/ ?>