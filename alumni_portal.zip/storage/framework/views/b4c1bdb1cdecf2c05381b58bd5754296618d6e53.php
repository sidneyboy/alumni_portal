<div class="row">
    <div class="col-md-12 grid-margin">
        <div class="card gedf-card">
            <div class="card-header">
                <div class="d-flex justify-content-between align-items-center">
                    <div class="d-flex justify-content-between align-items-center">
                        <div class="mr-2">
                            <img class="rounded-circle" width="45"
                                src="<?php echo e(asset('/image/' . $announcement->user->profile_picture)); ?>" alt>
                        </div>
                        <div class="ml-2">
                            <div class="h5 m-0">
                                <?php echo e('@' . Str::ucfirst($announcement->user->name)); ?> (Announcement)</div>
                            <div class="h7 text-muted">
                                <?php if($announcement->user_id == auth()->user()->id): ?>
                                    <?php echo e(Str::ucfirst($announcement->user->name)); ?>

                                    <?php echo e(Str::ucfirst($announcement->user->middle_name)); ?>

                                    <?php echo e(Str::ucfirst($announcement->user->last_name)); ?> 
                                <?php else: ?>
                                    <a style="text-decoration: none"
                                        href="<?php echo e(url('user_view_user', ['id' => $announcement->user_id])); ?>">
                                        <?php echo e(Str::ucfirst($announcement->user->name)); ?>

                                        <?php echo e(Str::ucfirst($announcement->user->middle_name)); ?>

                                        <?php echo e(Str::ucfirst($announcement->user->last_name)); ?></a>
                                <?php endif; ?>
                                <i
                                    style="color:#007bff;font-size:12px;">(<?php echo e(date('F j, Y', strtotime($announcement->created_at))); ?>)</i>
                            </div>
                        </div>
                    </div>
                    <div>
                        <div class="dropdown">
                            <button class="btn btn-link dropdown-toggle" type="button" id="gedf-drop1"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="fa fa-ellipsis-h"></i>
                            </button>
                            <div class="dropdown-menu dropdown-menu-right" aria-labelledby="gedf-drop1">
                                <div class="h6 dropdown-header">Configuration</div>
                                <a class="dropdown-item" href="#">Disable</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="card-body">
                <p class="card-text">
                    <?php echo e($announcement->body); ?>

                </p>
                <div class="container profile">
                    <div class="profile-img-list">
                        <?php if(count($announcement->attachments) == 0): ?>
                        <?php elseif(count($announcement->attachments) > 5): ?>
                            <div class="profile-img-list-item main"><a href="#"
                                    class="profile-img-list-link"><span class="profile-img-content"
                                        style="background-image: url(<?php echo e(asset('announcement_photos/' . $announcement->attachments_one->attachment)); ?>)"></span></a>
                            </div>
                            <?php $__currentLoopData = $announcement->attachments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="profile-img-list-item"><a href="#" class="profile-img-list-link"><span
                                            class="profile-img-content"
                                            style="background-image: url(<?php echo e(asset('announcement_photos/' . $item->attachment)); ?>)"></span></a>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <div class="profile-img-list-item with-number">
                                <a href="#" class="profile-img-list-link">
                                    <span class="profile-img-content"
                                        style="background-image: url(<?php echo e(asset('announcement_photos/' . $announcement->attachments_one->attachment)); ?>)"></span>
                                    <div class="profile-img-number">
                                        +<?php echo e(count($announcement->attachments)); ?></div>
                                </a>
                            </div>
                        <?php elseif(count($announcement->attachments) <= 5): ?>
                            <div class="profile-img-list-item main"><a href="#"
                                    class="profile-img-list-link"><span class="profile-img-content"
                                        style="background-image: url(<?php echo e(asset('announcement_photos/' . $announcement->attachments_one->attachment)); ?>)"></span></a>
                            </div>
                            <?php $__currentLoopData = $announcement->attachments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="profile-img-list-item"><a href="#" class="profile-img-list-link"><span
                                            class="profile-img-content"
                                            style="background-image: url(<?php echo e(asset('announcement_photos/' . $item->attachment)); ?>)"></span></a>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </div>
                </div>
                <a class="card-link" data-toggle="collapse" href="#collapseExampleuser_announcement_reply<?php echo e($announcement->id); ?>"
                    role="button" aria-expanded="false"
                    aria-controls="collapseExampleuser_announcement_reply<?php echo e($announcement->id); ?>">
                    <i class="fa fa-comment"></i> Comment
                </a>
                <a class="card-link" href="<?php echo e(url('user_announcement', ['id' => $announcement->id])); ?>">
                    <span class="badge badge-dark"><?php echo e(count($announcement->announcement_reply)); ?></span>
                    See Comments
                </a>
            </div>
            <div class="card-footer">
                <form action="<?php echo e(route('user_announcement_reply')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="collapse" id="collapseExampleuser_announcement_reply<?php echo e($announcement->id); ?>">
                        <div class="form-group">
                            <textarea name="content" required class="form-control" cols="30" rows="3"></textarea>
                            <input type="hidden" name="announcement_id" value="<?php echo e($announcement->id); ?>">
                        </div>
                        <button class="btn btn-sm float-right btn-primary">Reply</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>


<?php $__currentLoopData = $wall; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wall_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="row">
        <div class="col-md-12 grid-margin">
            <div class="card gedf-card">
                <div class="card-header">
                    <div class="d-flex justify-content-between align-items-center">
                        <div class="d-flex justify-content-between align-items-center">
                            <div class="mr-2">
                                <img class="rounded-circle" width="45"
                                    src="<?php echo e(asset('/image/' . $wall_item->user_admin->profile_picture)); ?>" alt>
                            </div>
                            <div class="ml-2">
                                <div class="h5 m-0">
                                    <?php echo e('@' . Str::ucfirst($wall_item->user_admin->name)); ?></div>
                                <div class="h7 text-muted">
                                    <?php if($wall_item->user_id == auth()->user()->id): ?>
                                        <?php echo e(Str::ucfirst($wall_item->user_admin->name)); ?>

                                        <?php echo e(Str::ucfirst($wall_item->user_admin->middle_name)); ?>

                                        <?php echo e(Str::ucfirst($wall_item->user_admin->last_name)); ?>

                                    <?php else: ?>
                                        <a style="text-decoration: none"
                                            href="<?php echo e(url('user_view_user', ['id' => $wall_item->user_id])); ?>">
                                            <?php echo e(Str::ucfirst($wall_item->user_admin->name)); ?>

                                            <?php echo e(Str::ucfirst($wall_item->user_admin->middle_name)); ?>

                                            <?php echo e(Str::ucfirst($wall_item->user_admin->last_name)); ?></a>
                                    <?php endif; ?>
                                    <i
                                        style="color:#007bff;font-size:12px;">(<?php echo e(date('F j, Y', strtotime($wall_item->created_at))); ?>)</i>
                                </div>
                            </div>
                        </div>
                        <div>
                            <div class="dropdown">
                                <button class="btn btn-link dropdown-toggle" type="button" id="gedf-drop1"
                                    data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    <i class="fa fa-ellipsis-h"></i>
                                </button>
                                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="gedf-drop1">
                                    <div class="h6 dropdown-header">Configuration</div>
                                    <a class="dropdown-item" href="#">Disable</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="card-body">
                    <p class="card-text">
                        <?php echo e($wall_item->body); ?>

                    </p>
                    <div class="container profile">
                        <div class="profile-img-list">
                            <?php if(count($wall_item->attachments) == 0): ?>
                            <?php elseif(count($wall_item->attachments) > 5): ?>
                                <div class="profile-img-list-item main"><a href="#"
                                        class="profile-img-list-link"><span class="profile-img-content"
                                            style="background-image: url(<?php echo e(asset('announcement_photos/' . $wall_item->attachments_one->attachment)); ?>)"></span></a>
                                </div>
                                <?php $__currentLoopData = $wall_item->attachments_limit_3; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="profile-img-list-item"><a href="#"
                                            class="profile-img-list-link"><span class="profile-img-content"
                                                style="background-image: url(<?php echo e(asset('announcement_photos/' . $item->attachment)); ?>)"></span></a>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <div class="profile-img-list-item with-number">
                                    <a href="#" class="profile-img-list-link">
                                        <span class="profile-img-content"
                                            style="background-image: url(<?php echo e(asset('announcement_photos/' . $wall_item->attachments_one->attachment)); ?>)"></span>
                                        <div class="profile-img-number">
                                            +<?php echo e(count($wall_item->attachments)); ?></div>
                                    </a>
                                </div>
                            <?php elseif(count($wall_item->attachments_limit_3) <= 5): ?>
                                <div class="profile-img-list-item main"><a href="#"
                                        class="profile-img-list-link"><span class="profile-img-content"
                                            style="background-image: url(<?php echo e(asset('announcement_photos/' . $wall_item->attachments_one->attachment)); ?>)"></span></a>
                                </div>
                                <?php $__currentLoopData = $announcement->attachments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="profile-img-list-item"><a href="#"
                                            class="profile-img-list-link"><span class="profile-img-content"
                                                style="background-image: url(<?php echo e(asset('announcement_photos/' . $item->attachment)); ?>)"></span></a>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>


                        </div>
                    </div>
                    <a class="card-link" data-toggle="collapse"
                        href="#collapseExampleuser_wall_reply<?php echo e($wall_item->id); ?>" role="button"
                        aria-expanded="false" aria-controls="collapseExampleuser_wall_reply<?php echo e($wall_item->id); ?>">
                        <i class="fa fa-comment"></i> Comment
                    </a>
                    <a class="card-link" href="<?php echo e(url('user_wall', ['id' => $wall_item->id])); ?>">
                        <span class="badge badge-dark"><?php echo e(count($wall_item->wall_replies)); ?></span>
                        See Comments
                    </a>
                </div>
                <div class="card-footer">
                    <form action="<?php echo e(route('user_wall_reply')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="collapse" id="collapseExampleuser_wall_reply<?php echo e($wall_item->id); ?>">
                            <div class="form-group">
                                <textarea name="content" required class="form-control" cols="30" rows="3"></textarea>
                                <input type="hidden" name="wall_id" value="<?php echo e($wall_item->id); ?>">
                            </div>
                            <button class="btn btn-sm float-right btn-primary">Reply</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH C:\Users\Administrator\Documents\GitHub\alumni_portal\resources\views/user_get_new_feed.blade.php ENDPATH**/ ?>